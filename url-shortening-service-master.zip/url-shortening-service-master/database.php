<!Doctype html>
<html>
<head>
	<title>Connecting to a Database</title>
</head>
<body>
	<?php>
		$con = mysql_connect("localhost","root","");
		$db = mysql_select_db("my_database");
		
		if($con){
			echo'Successfully connected to database';
		}
		else
			die'Error!';
			
	<?>
</body>
</html>
	