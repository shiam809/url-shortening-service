
if (isset($_GET["link"])) {
	$conn = mysqli_connect('localhost','zarjis','123456','url');
	$link = $_GET["link"];
	$fetchquery = "SELECT * FROM shorturl WHERE shorturl= '$link'";
	$fetchresult = mysqli_query($conn,$fetchquery);
	while ($row = mysqli_fetch_assoc($fetchresult)) {
		$visitlongurl = $row ["longurl"];
		header ("Location: $visitlongurl");
		exit();
	}
}
?>