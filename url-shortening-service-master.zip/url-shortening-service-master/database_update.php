<!Doctype html>
<html>
<head>
	<title>Connecting to a Database</title>
</head>
<body>
	<table>
	<?php>
		$con = mysql_connect("localhost","root","");
		$db = mysql_select_db("my_database");
		
		if($con){
			echo'Successfully connected to database';
		}
		else{
			die'Error!';
		}
		if ($bd){
			echo'Successfully found the database';
		}
		else{
			die'Error!! Database not found';
		}
		<br />
		<br />
		
		
		<?php
			$query = mysql_query("SELECT * FROM data");
			$records=mysql_query($query);
			
			while($url short=mysql_assoc($records)){
			<tr>
				<td><?php echo $row['u']; ?></td>
				<td><?php echo $row['V']; ?></td>

			</tr>
		
		?>
		<
			
	?>
	/table>
</body>
</html>
	