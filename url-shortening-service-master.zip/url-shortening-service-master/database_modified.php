<!DOCTYPE html>
<html>
<head>
 <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" type="text/css"  href="t_style.css">
		
	<title>URL Shortening Service </title>
<head>
 
<body>
	<center>

		<h1>URL Shortening Service</h1>
		<form method="POST"  action="index.php">
		Enter your Url: <input type="text" name="urlshort" size="40"  placeholder="Enter here" > <br><br>
		<input type="submit" name="submit" style="color: blue">
		<body style="background-color:powderblue;">
        </center>
		<style>
.footer {
   
    left: 0;
    bottom: 0;
    width: 100%;
    height: 20%;
    background-color: black;
    border-top: 3px solid red;
    color: white;
    text-align: center;
}
</style>
<div> 
<table>
 
     <tr>
	 
	 <th class="footer"  >HISTORY</th>
	 </tr>
	 <tr>
	   <td>    </td>

	 </tr>
	  <tr>
	   <td>    </td>
	
	 </tr>
	  <tr>
	   <td>    </td>
	 </tr>
	 <tr>
	   <td>    </td>
	 </tr>
	 <tr>
	   <td>    </td>
	 </tr>
	 <tr>
	   <td>    </td>
	 </tr>
	  <tr>
	   <td>    </td>
	 </tr>
	  <tr>
	   <td>    </td>
	 </tr>
	  <tr>
	   <td>    </td>
	 </tr>
     <tr>
	   <td>    </td>
	 </tr>



	
	
	  
</table>
 
<div class="footer">
  <p>Contract us</p>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
   <p><i class="fa fa-envelope"></i> <a href="mailto:shiamkhan809@gmail.com">
  shiamkhan809@gmail.com</a></p>
  <footer>&copy; Copyright By Group-4</footer>

</div>

<?php
if (isset($_POST["submit"])){
	$conn = mysqli_connect('localhost','zarjis','123456','url');
	$longurl = $_POST ["urlshort"];
	$shorturl = substr(md5( microtime()), rand(0,26),5);
	$query = "INSERT INTO shorturl (shorturl,longurl) VALUES ('$shorturl','$longurl')";
	$result = mysqli_query($conn,$query);
	if ($result) {
		echo "Your Short Url Link is ::  http://localhost/url/$shorturl ";
	}
	else{
		echo "We are facing some problems";
	}
}

if (isset($_GET["link"])) {
	$conn = mysqli_connect('localhost','zarjis','123456','url');
	$link = $_GET["link"];
	$fetchquery = "SELECT * FROM shorturl WHERE shorturl= '$link'";
while ($row = mysqli_fetch_assoc($fetchresult)) {
		$visitlongurl = $row ["longurl"];
		header ("Location: $visitlongurl");
		exit();
	}
}
?>