<?php>
$sql = "SELECT * FROM shorturl";
$result = mysqli_query($con, $sql);
echo '<table>';
echo '<tr><th>ID</th><th>Long URL</th><th>Short URL</th></tr>';
while($row = mysqli_fetch_assoc($result)){
    echo '<tr><td>'.$row['id'].'</td><td>'.$row['longurl'].'</td><td>'.$row['shorturl'].'</td></tr>';
}
echo '</table>';}
	
		header ("Location: $visitlongurl");
		exit();
	}
}
?>