<!DOCKTYPE html> 
<html>
<head>
 <title> URL Shortening Service</title>
<head>
<body>
<center>
  <h1>URL Shortening Service</h1>
  <form method="POST" action="index.php">
  enter your short url url :<input type= "text"
</center>
<body>
<html>