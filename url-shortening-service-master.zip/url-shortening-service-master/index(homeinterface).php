<!DOCTYPE html>
<html>
<head>
	<title>URL Shortening Service </title>
<head>
<body>
	<center>
		<h1>URL Shortening Service</h1>
		<form method="POST" action="index.php">
		Enter your Url: <input type="text" name="urlshort" placeholder="Enter here"> <br><br>
		<input type="submit" name="submit">
		</form>
	</center>
</body>
</html>